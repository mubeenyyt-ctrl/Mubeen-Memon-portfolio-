# Mubeen Memon — Portfolio

A single-page portfolio site built with plain HTML/CSS/JS (no build step needed).

## Push to GitHub & publish with GitHub Pages

```bash
# 1. Create a new repo on GitHub named e.g. "portfolio" (or username.github.io for a root site)

# 2. From this folder:
git init
git add .
git commit -m "Initial portfolio site"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main

# 3. Enable GitHub Pages
# Go to: Repo → Settings → Pages → Source: "main" branch, "/ (root)" → Save
# Your site will be live at:
# https://<your-username>.github.io/<repo-name>/
```

If you name the repo `<your-username>.github.io`, your site will be live at the root domain `https://<your-username>.github.io/` instead of a subpath.

## Files
- `index.html` — the entire site (HTML, CSS, JS in one file)
